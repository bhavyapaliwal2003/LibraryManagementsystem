<?php
include('connect.php');
	//Create Connection
	// $conn = new PDO($dsn, $db_user, $db_password);


	// Insert Data
	if(isset($_REQUEST['submit'])){
	//Checking for empty field
	if(($_REQUEST['id'] == "") || ($_REQUEST['guestname'] == "") ||($_REQUEST['guestemail'] == "")){
		echo "<small>Fill all Fields</small><hr>";
	}else{
		$id = $_REQUEST['id'];
		$guestname = $_REQUEST['guestname'];
		$guestemail = $_REQUEST['guestemail'];
		
		$sql = "INSERT INTO guest(id,guestname, guestemail) VALUES('$id','$guestname', '$guestemail')";
		// $affected_row = $conn->exec($sql);
		// echo $affected_row . "Row Inserted Successfuly <br>";
	}
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Guest List</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<div class="container">
  <h2>Form</h2>
  <div class="row">
  <div class="col-sm-4">
  <form action="" method="POST">
      <div class="form-group">
      <label for="name">id:</label>
      <input type="text" class="form-control" autocomplete="off" name="id" id="id">
    </div>
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" autocomplete="off" name="guestname" id="guestname">
    </div>
    <div class="form-group">
      <label for="roll">Gmail:</label>
      <input type="roll" class="form-control" autocomplete="off" name="guestemail" id="guestemail">
    </div>
   
    
    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
  </form>
  </div>
  

  <div class="col-sm-6 offset-sm-2">
    <?php
    $sql = "SELECT * FROM guest";
    $result = $query($sql);
    if($result->rowCount() > 0){
      echo '<table class="table table-bordered">';
        echo "<thead>";
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Name</th>";
        echo "<th>gmail</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
      while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["guestname"] . "</td>";
        echo "<td>" . $row["guestemail"] . "</td>";
        echo "</tr>";
      }
      echo "</tbody>";
      echo "</table>";

    }else{
      echo "0 Result";
    }
  ?>
</div>
  </div>
</div>

</body>
</html>
