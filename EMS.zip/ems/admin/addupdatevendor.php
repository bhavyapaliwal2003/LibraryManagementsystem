<?php
session_start();
error_reporting(0);
include('connect.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Add/Update Vendor</title>

</head>
<body>
<?php include('includes/header.php');?>
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Manage Vendor

                </h4>
    </div>


        </div>
            <div class="row">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          User
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table >
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>VendorID</th>
                                            <th>Vendor Name</th>
                                            <th>Email id </th>
                                            <th>Mobile Number</th>
                                          </tr>
                                    </thead>
                                    <tbody>
<?php $sql = "SELECT * from tblvendor";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>                                      
                                        <tr class="odd gradeX">
                                            <td class="center"><?php echo htmlentities($cnt);?></td>
                                            <td class="center"><?php echo htmlentities($result->vendorId);?></td>
                                            <td class="center"><?php echo htmlentities($result->FullName);?></td>
                                            <td class="center"><?php echo htmlentities($result->EmailId);?></td>
                                            <td class="center"><?php echo htmlentities($result->MobileNumber);?></td>                                            </td>
                                            <td class="center">                                       
                                            </td>
                                        </tr>
 <?php $cnt=$cnt+1;}} ?>                                      
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>


            
    </div>
    </div>


</body>
</html>
<?php } ?>
