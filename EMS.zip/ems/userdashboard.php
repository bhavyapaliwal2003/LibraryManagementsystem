<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>
    <h1>User Dashboard</h1>
    <button type="submit"><a href="user\vendormanage.php">Vendor</a></button>
    <button type="submit"><a href="user\cart.php">Cart</a></button>
    <button type="submit"><a href="user\guestlist.php">Guest List</a></button>
    <button type="submit"><a href="user\orderstatus.php">Order Status</a></button>
</body>
</html>