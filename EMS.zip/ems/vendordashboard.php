<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Dashboard</title>
</head>
<body>
    <h1>Main Page</h1>
    <button type="submit"><a href="vendor/youritem.php">Your Item</a></button>
    <button type="submit"><a href="vendor/addnewitem.php">Add New Item</a></button>
    <button type="submit"><a href="vendor/tranasaction.php">Transaction</a></button>
</body>
</html>