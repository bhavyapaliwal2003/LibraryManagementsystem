<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Maintanence Menu</h1>
    <button type="submit"><a href="admin/addupdatemember.php">Add/Update Memeber</a></button>
    <button type="submit"><a href="admin/addupdateuser.php">Add/Update User </a></button>
    <button type="submit"><a href="admin/addupdatevendor.php">Add/Update Vendor </a></button>
    <button type="submit"><a href="admin/usermanagement.php">User Management</a></button>
    <button type="submit"><a href="admin/vendormanagement.php"> Vendor management</a></button>

</body>
</html>