<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>event management system</h1>
    <button type="submit"><a href="vendor.php">vendor</a></button>
    <button type="submit"><a href="admin.php">Admin</a></button>
    <button type="submit"><a href="user.php">User</a></button>

</body>
</html>